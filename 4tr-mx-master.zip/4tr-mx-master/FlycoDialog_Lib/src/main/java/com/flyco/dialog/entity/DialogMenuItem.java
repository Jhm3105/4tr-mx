package com.flyco.dialog.entity;

public class DialogMenuItem {
    public String mOperName;
    public int mResId;

    public DialogMenuItem(String operName, int resId) {
        mOperName = operName;
        mResId = resId;
    }
}
