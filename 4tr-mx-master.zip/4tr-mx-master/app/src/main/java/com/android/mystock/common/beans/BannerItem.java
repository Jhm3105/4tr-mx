package com.android.mystock.common.beans;

public class BannerItem {
    public String imgUrl;
    public String title;
}
