package com.android.mystock.ui.homepages.mvp.view;

/**
 * 登录程序的第一个页面
 */
public interface I_View_Login extends I_View_Base {

    public void onResponse();
}
