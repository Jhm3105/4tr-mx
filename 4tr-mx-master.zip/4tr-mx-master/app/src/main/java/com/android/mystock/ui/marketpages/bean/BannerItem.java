package com.android.mystock.ui.marketpages.bean;

public class BannerItem {
    public String imgUrl;
    public String title;
}
